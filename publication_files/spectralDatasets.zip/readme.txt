This file contains the description of data that accompanies the paper:  
Azadeh Asadi Shahmirzadi, Vahid Babaei, Hans-Peter Seidel, "A Multispectral Dataset of Oil and Watercolor Paints", Material Appearnce Conference, Electronic Imaginng 2020  

- "oilspectra.txt": 286 spectra (from 400 to 700 nm with 10 nm intervals) of a swatch of oil colors. 

- "oilmixtureportions.txt": the portions of the 8 underlying paints used in the "oilspectra" dataset. The oil paints (Old Holland) from first to 8th column are: Lemon Yellow, Cadmium Yellow, Scarlet Lake, Alizarine Lake, Coblat Blue, Ultramarine Blue, Viridian Green, White. 

- "watercolorspectra.txt": 397 spectra (from 400 to 700 nm with 10 nm intervals) of a swatch of watercolor colors. 

- "watercolormixtureportions.txt": the portions of WATER and 9 underlying paints used in the "watercolorspectra" dataset. The first column contains water portions. The second to 10th columns shwo watercolor paints (Schmincke): Lemon Yellow, Cadmium Yellow Light, Yellow Ochre,Cadmium Red Light, Permanent Carmin, Phthalo Green, Prussian Blue, Ultramarine finest, Ivory Black. 

- "watercolorfineartpaper.txt": the spectrum (from 400 to 700 nm with 10 nm intervals) of the fine art paper used as substrate of the watercolor swatch. 